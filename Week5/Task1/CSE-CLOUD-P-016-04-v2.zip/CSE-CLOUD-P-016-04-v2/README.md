# CSE-CLOUD-P-016-04 — Source Code Secret Exposure Detection and Cloud Credential Incident Response (Report Variant)

Junior Cloud Security Engineer Internship — EncryptEdge Labs, Cohort 7

## Overview

This is a variant/revision of the CSE-CLOUD-P-016-04 incident report. It
keeps the same secret-exposure and IAM-containment narrative as the
original submission but reframes Phase D around **EC2 IMDSv1 credential
theft** (SSRF against the instance metadata service leading to stolen IAM
role credentials) rather than the direct IAM access-key rotation walkthrough
used in the other version, and closes with reflection questions on IMDSv2
and ISO/IEC 27001 controls instead.

- **Skill domain:** Cloud Security / Incident Response / Secret Management
- **Difficulty:** Advanced
- **CPE Credits:** 4
- **Guiding frameworks:** MITRE ATT&CK, NIST Incident Response lifecycle, AWS IAM security practices, ISO/IEC 27001:2022 Annex A

## Contents

| File | Description |
|---|---|
| `CSE_AWS_IR_Report.pdf` | Final incident report (Phases A–F, findings, risk matrix, recommendations, IMDSv2/ISO 27001 reflection) |
| `evidence/phaseA_threatmodel.png` | EC2 credential-theft threat model diagram — IMDSv1 exposure, attack path, and mitigations |
| `evidence/phaseB_resources.png` | AWS CLI `describe-instances` output showing lab EC2 instance state/IAM profile, plus a Terraform provider install error encountered during setup |

## Evidence Gaps

The report references several Phase D/E deliverables that were **not**
included in this upload and are not present in this folder:

- `phaseD_iocs.txt` — documented indicators of compromise
- `phaseD_logs.zip` — packaged forensic log evidence
- `gitleaks_report.json` / `phaseC_validation.png` — not produced (Phase C target repository was inaccessible, as documented in the report)
- `phaseE_labproof.png` — hosted-lab completion proof, marked Pending in the report

These should be added before this is treated as a complete submission
package.

## Redactions

- **Intern's personal email address** — redacted from the "Intern Email"
  field on page 1 of the report PDF.
- **EC2 instance IDs** — both instance IDs in `evidence/phaseB_resources.png`
  (`i-08964f8ba...` and `i-02c47cafe...`) are blacked out and labeled
  `[INSTANCE-ID-REDACTED]`, since they're specific identifiers tied to a
  real (if authorized/lab) AWS account.

No AWS account IDs, access keys, or ARNs were present in either evidence
screenshot.

## Scope & Authorization

All technical activities were performed in AWS CloudShell against an
authorized personal AWS lab account and the CloudGoat vulnerable-by-design
training environment. No production systems, third-party accounts, or real
customer data were accessed.
